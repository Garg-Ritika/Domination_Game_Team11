Domination Game


**commands for map-editor**
- editcontinent -add asia 2 -add america 3 -add africa 4
- editcountry -add india asia -add china asia -add pak china
- editneighbor -add india china -add pak china -add india pak
- showmap
- savemap d:\abc.map
- editmap d:\abc.map
- validatemap

**commands for game-play**
- loadmap D:\maps\canada\canada.map
- gameplayer -add binit -add gurseerut -add satinder -add ritika -add nilesh
- assigncountries
- showmap
- deploy india 1
